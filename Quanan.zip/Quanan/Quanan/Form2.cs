﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quanan
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            LoadListView();
            LoadListView2();
        }

        private void hjhkToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        void LoadListView()
        {
           
            ListViewItem t1 = new ListViewItem();
            t1.Text = "Cá rô";
            t1.SubItems.Add(new ListViewItem.ListViewSubItem() { Text = "20000" });
            listView1.Items.Add(t1);
            ListViewItem t2 = new ListViewItem();
            t2.Text = "Gà quay";
            t2.SubItems.Add(new ListViewItem.ListViewSubItem() { Text = "120000" });
            listView1.Items.Add(t2);
        }
        void LoadListView2()
        {
            
        }
        private void accountToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            foreach (Form oForm in Application.OpenForms)
            {
                if (oForm is Form1)
                {
                    oForm.Show();
                    break;
                }
            }
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            ListViewItem t = new ListViewItem();
            bool err = false;
            string gia = txtgia.Text;
            for (int i = 0; i < gia.Length; i++)
            {
                if ( gia[i] < '0' || gia[i] > '9')
                {
                    err = true;
                    break;
                }
            }
            if (err)
            {
                MessageBox.Show("Giá tiền phải là các chữ số", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (txtgia.Text == "") MessageBox.Show("Bạn chưa nhập giá!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (txtmon.Text == "") MessageBox.Show("Bạn chưa nhập tên món!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (txtgia.Text != "" && txtmon.Text != "")
                {
                    t.Text = txtmon.Text;
                    t.SubItems.Add(new ListViewItem.ListViewSubItem() { Text = txtgia.Text });
                    listView1.Items.Add(t);
                    txtgia.Text = txtmon.Text = "";
                }
            }
        }
        public string changetoVND(string x)
        {
            int l = x.Length;
            int dem = 0;
            string y = "";
            string result = "";
            //while (x[length] != '\0')
            //{
            //    length++;
            //}
            for (int i=l-1;i>=0;i--)
            {
                y += x[i];
            }
            for (int i=0 ;i<l;i++)
            {
                if (dem != 2)
                {
                    dem++;
                    result += y[i];
                }
                else
                {
                    if (i != l-1)
                    { 
                        result += y[i];
                        result += ',';
                    }
                    else
                    {
                        result += y[i];
                    }
                    dem = 0;
                }
            }
            l = result.Length;
            string realresult = "";
            for (int i =l-1;i>=0;i--)
            {
                realresult += result[i];
            }
            return realresult;
        }
        public string changetoso(string x)
        {
            string y = "";
            int i = 0;
            while (i != x.Length)
            {
                if (x[i] == ',') i++;
                else
                {
                    y += x[i];
                    i++;
                }
            }
            return y;
        }
        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            ListView a = sender as ListView;
            if (a.SelectedItems.Count > 0)
            {
                ListViewItem item = new ListViewItem(a.SelectedItems[0].Text);
                if (item.Text != "")
                {
                    //item.SubItems[0].Text = a.SelectedItems[0].SubItems[0].Text;
                    string price = a.SelectedItems[0].SubItems[1].Text;
                    item.SubItems.Add(new ListViewItem.ListViewSubItem() { Text = price });
                    listView2.Items.Add(item);
                    if (tbtotal.Text != "")
                    {
                        double money = double.Parse(tbtotal.Text);
                        tbtotal.Text = "";
                        string abc = Convert.ToString(double.Parse(price) + money);

                        tbtotal.Text += changetoVND(abc);
                    }
                    else tbtotal.Text += changetoVND(price);
                }
            }
        }

        private void btnpay_Click(object sender, EventArgs e)
        {
            listView2.Clear();
            // 
            if (tbtotal.Text == "") MessageBox.Show("Hóa đơn trống!","", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else MessageBox.Show("Số tiền quý khách phải trả là " + tbtotal.Text + "đ" , "Thanh toán thành công");
            tbtotal.Text = "";
        }

        private void btndlt_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count == 0)
            {
                return;
            }
            else
            {
                string x = changetoso(tbtotal.Text);
                double y = Convert.ToDouble(x) - Convert.ToDouble(listView2.SelectedItems[0].SubItems[1].Text);
                tbtotal.Text = "";
                if (y!=0)
                tbtotal.Text += changetoVND(Convert.ToString(y));
                else
                listView2.Items.Remove(listView2.SelectedItems[0]);
            }
        }
    }
}
