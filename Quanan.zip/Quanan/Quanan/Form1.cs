﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quanan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (txt1.Text == "abc" && txt2.Text == "123")
            {
                this.Hide();
                Form2 f = new Form2();
                f.Show();
            }
            else
            {
                MessageBox.Show("Wrong username or password !");
            }
        }

        private void txt2_TextChanged(object sender, EventArgs e)
        {

        }

        private void check_CheckedChanged(object sender, EventArgs e)
        {
            if (check.Checked) txt2.UseSystemPasswordChar = false;
            else txt2.UseSystemPasswordChar = true;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
        //    if (MessageBox.Show("Bạn có muốn tắt thật không?", "Tắt", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            //{
//e.Cancel = true;
          //  }

        }
    }
    
}
